clear;
clc;
close all;
%%
% Import the files: Stage I-case/adj_network_idx/adj_network_weight
fpi1=fopen('stageI_exp.txt');
hline1 = textscan(fpi1, '%s', 1, 'delimiter', '\n');
field1=textscan(hline1{1}{1},'%s');
clear format;
format1='%s';
% format1=[format1,' %s'];
for i=2:223
    format1=[format1,' %f'];
end
lines1 =textscan(fpi1, format1,1000000,'delimiter', '\t');
genename1=lines1{1};
pprofile1 = [];
for i = 2:223
    pprofile1 = [pprofile1, lines1{i}];
end
fclose(fpi1);
fid1=fopen('stageI_idx_gene.txt');
stageI_wgcna_network={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    stageI_wgcna_network{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
total_node_num1=j;
fid1=fopen('stageI_weight_network.txt');
stageI_weight_network={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    stageI_weight_network{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
pprofile1=abs(pprofile1);
psize1=size(pprofile1);
% Calculate the node probability and local network flow entropy for each network 
for na1=1:total_node_num1
     weight_sum1=zeros(length(stageI_weight_network),1);
     for n1=2:length(stageI_wgcna_network{na1})-1 
        nei1=stageI_wgcna_network{na1}{n1};% neighborhood gene in each local network
        ne1=str2num(nei1);
        m1=mean(pprofile1(ne1,1:psize1(2)));% mean of each neighborhood gene
        v1=std(pprofile1(ne1,1:psize1(2)));% standard deviation of each neighborhood gene
        for j=1:psize1(2) 
            p1(n1-1,j)=normpdf(pprofile1(ne1,j),m1,v1); % Gaussian distribution for each neighborhood gene
            p_node1(n1-1,j)=p1(n1-1,j)./sum(p1(n1-1,:));  % node probability of each neighborhood gene
            entropy_node1(na1,n1-1)=-sum(pprofile1(ne1,j).*p_node1(n1-1,j).*log(abs(pprofile1(ne1,j).*p_node1(n1-1,j)))); % local network flow entropy
        end
     end
end
% Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na1=1:total_node_num1
  legt_wegt1(na1)=length(stageI_weight_network{na1});  
end
for na1=1:total_node_num1
     for n1=2:length(stageI_weight_network{na1})-1
         max_legt_wegt1=max(legt_wegt1);
         idx1=stageI_weight_network{na1}{n1};
         id1=str2num(idx1);
         weight_sum1(na1)=weight_sum1(na1)+sum(str2num(char(reshape(stageI_weight_network{na1},legt_wegt1(na1),1))))-na1;
         center1=stageI_wgcna_network{na1}{1}; % center gene in each local network
         center1=str2num(center1);
         m=mean(pprofile1(center1,1:psize1(2)));% mean of each center gene 
         v=std(pprofile1(center1,1:psize1(2))); % standard deviation of each center gene
         for j=1:psize1(2)
         p11(na1,j)=normpdf(pprofile1(na1,j),m,v); % Gaussian distribution for each center gene
         p_center1=normpdf(pprofile1(na1,j),m,v)./sum(p11(na1,:)); % node probability of each center gene 
         p_cond1(na1,n1-1)=(str2num(stageI_weight_network{na1}{n1}))./weight_sum1(na1); 
         exp1=pprofile1(n1-1,j);
         entropy_cond1(na1,n1-1)=-sum(exp1.*p_center1.* p_cond1(na1).*log(abs(exp1.*p_cond1(na1)))); % conditional network flow entropy
         MI_cond1(na1,n1-1)=entropy_node1(na1,n1-1)-entropy_cond1(na1,n1-1); % differential network flow entropy
         end
         MI_sum1(na1)=mean(MI_cond1(na1,:));
     end  
end
% Stage I network flow entropy
TNFE_stageI=sum(MI_sum1(:))/total_node_num1;


%%
%Import the files: Stage II-case/adj_network_idx/adj_network_weight
fpi2=fopen('stageII_exp.txt');
hline2 = textscan(fpi2, '%s', 1, 'delimiter', '\n');
field2=textscan(hline2{1}{1},'%s');
clear format2;
format2='%s';
% format2=[format2,' %s'];
for i=2:138
    format2=[format2,' %f'];
end
lines2=textscan(fpi2, format2,1000000,'delimiter', '\t');
genename2=lines2{1};
pprofile2= [];
for i = 2 :138
    pprofile2 = [pprofile2, lines2{i}];
end
fclose(fpi2);
fid2=fopen('stageII_idx_gene.txt');
stageII_wgcna_network={};
j=0;
while ~feof(fid2)
    tline2=fgetl(fid2);
    j=j+1;
    stageII_wgcna_network{j}=regexp(tline2, '\s+', 'split');
end
fclose(fid2);
total_node_num2=j;
fid2=fopen('stageII_weight_network.txt');
stageII_weight_network={};
j=0;
while ~feof(fid2)
    tline2=fgetl(fid2);
    j=j+1;
    stageII_weight_network{j}=regexp(tline2, '\s+', 'split');
end
fclose(fid2);
pprofile2=abs(pprofile2);
psize2=size(pprofile2);
%Calculate the node probability and local network flow entropy for each network
for na2=1:total_node_num2
     weight_sum2=zeros(length(stageII_weight_network),1);
     for n2=2:length(stageII_wgcna_network{na2})-1
        nei2=stageII_wgcna_network{na2}{n2};% neighborhood gene in each local network
        ne2=str2num(nei2);
        m2=mean(pprofile2(ne2,1:psize2(2)));% mean of each neighborhood gene
        v2=std(pprofile2(ne2,1:psize2(2)));% standard deviation of each neighborhood gene
        for j=1:psize2(2)
            p2(n2-1,j)=normpdf(pprofile2(ne2,j),m2,v2);% Gaussian distribution for each neighborhood gene
            p_node2(n2-1,j)=p2(n2-1,j)./sum(p2(n2-1,:));  % node probability of each neighborhood gene
            entropy_node2(na2,n2-1)=-sum(pprofile2(ne2,j).*p_node2(n2-1,j).*log(abs(pprofile2(ne2,j).*p_node2(n2-1,j)))); % local network flow entropy
        end
     end
end
%Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na2=1:total_node_num2
  legt_wegt2(na2)=length(stageII_weight_network{na2});  
end
for na2=1:total_node_num2
     for t2=2:length(stageII_weight_network{na2})-1
         max_legt_wegt2=max(legt_wegt2);
         idx2=stageII_weight_network{na2}{t2};
         id2=str2num(idx2);
         weight_sum2(na2)=weight_sum2(na2)+sum(str2num(char(reshape(stageII_weight_network{na2},legt_wegt2(na2),1))))-na2;
         center2=stageII_wgcna_network{na2}{1};% center gene in each local network
         center2=str2num(center2);
         m_2=mean(pprofile2(center2,1:psize2(2)));% mean of each center gene
         v_2=std(pprofile2(center2,1:psize2(2)));% standard deviation of each center gene
         for j=1:psize2(2) 
         p22(na2,j)=normpdf(pprofile2(na2,j),m_2,v_2); % Gaussian distribution for each center gene
         p_center2=p22(na2,j)./sum(p22(na2,:)); % node probability of each center gene
         p_cond2(na2,t2-1)=(str2num(stageII_weight_network{na2}{t2}))./weight_sum2(na2);
         exp2=pprofile2(t2-1,j);
         entropy_cond2(na2,t2-1)=-sum(exp2.*p_center2.* p_cond2(na2).*log(abs(exp2.*p_cond2(na2))));% conditional network flow entropy
         MI_cond2(na2,t2-1)=entropy_node2(na2,t2-1)-entropy_cond2(na2,t2-1);% differential network flow entropy
         MI_sum2(na2)=mean(MI_cond2(na2,:));
         end
     end  
end
% Stage II network flow entropy
TNFE_stageII=sum(MI_sum2(:))/total_node_num2;

%%
%Import the files: Stage IIIA-case/adj_network_idx/adj_network_weight
fpi3=fopen('stageIIIA_exp.txt');
hline3= textscan(fpi3, '%s', 1, 'delimiter', '\n');
field3=textscan(hline3{1}{1},'%s');
clear format3;
format3='%s';
% format3=[format3,' %s'];
for i=2:119
    format3=[format3,' %f'];
end
lines3=textscan(fpi3, format3,1000000,'delimiter', '\t');
genename3=lines3{1};
pprofile3= [];
for i = 2 :119
    pprofile3= [pprofile3, lines3{i}];
end
fclose(fpi3);
fid3=fopen('stageIIIA_idx_gene.txt');
stageIIIA_wgcna_network={};
j=0;
while ~feof(fid3)
    tline3=fgetl(fid3);
    j=j+1;
    stageIIIA_wgcna_network{j}=regexp(tline3, '\s+', 'split');
end
fclose(fid3);
total_node_num3=j;
fid3=fopen('stageIIIA_weight_network.txt');
stageIIIA_weight_network={};
j=0;
while ~feof(fid3)
    tline3=fgetl(fid3);
    j=j+1;
    stageIIIA_weight_network{j}=regexp(tline3, '\s+', 'split');
end
fclose(fid3);
pprofile3=abs(pprofile3);
psize3=size(pprofile3);
%Calculate the node probability and local network flow entropy for each network 
for na3=1:total_node_num3
     weight_sum3=zeros(length(stageIIIA_weight_network),1);   
     for n3=2:length(stageIIIA_wgcna_network{na3})-1
        nei3=stageIIIA_wgcna_network{na3}{n3};% neighborhood gene in each local network
        ne3=str2num(nei3);
        m3=mean(pprofile3(ne3,1:psize3(2)));% mean of each neighborhood gene
        v3=std(pprofile3(ne3,1:psize3(2)));% standard deviation of each neighborhood gene
        for j=1:psize3(2) 
            p3(n3-1,j)=normpdf(pprofile3(ne3,j),m3,v3);
            p_node3(n3-1,j)=p3(n3-1,j)./sum(p3(n3-1,:));  % node probability of each neighborhood gene
            entropy_node3(na3,n3-1)=-sum(pprofile3(ne3,j).*p_node3(n3-1,j).*log(abs(pprofile3(ne3,j).*p_node3(n3-1,j)))); % local network flow entropy
        end
     end
end
%Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na3=1:total_node_num3
  legt_wegt3(na3)=length(stageIIIA_weight_network{na3});  
end
for na3=1:total_node_num3
     for t3=2:length(stageIIIA_weight_network{na3})-1
         max_legt_wegt3=max(legt_wegt3);
         idx3=stageIIIA_weight_network{na3}{t3};
         id3=str2num(idx3);
         weight_sum3(na3)=weight_sum3(na3)+sum(str2num(char(reshape(stageIIIA_weight_network{na3},legt_wegt3(na3),1))))-na3;
         center3=stageIIIA_wgcna_network{na3}{1};% center gene in each local network
         center3=str2num(center3);
         m_3=mean(pprofile3(center3,1:psize3(2)));% mean of each center gene 
         v_3=std(pprofile3(center3,1:psize3(2)));% standard deviation of each center gene
         for j=1:psize3(2)  
         p33(na3,j)=normpdf(pprofile3(na3,j),m_3,v_3);
         p_center3=normpdf(p33(na3,j))./sum(p33(na3,:));% node probability of each center gene 
         p_cond3(na3,t3-1)=(str2num(stageIIIA_weight_network{na3}{t3}))./weight_sum3(na3);
         exp3=pprofile3(t3-1,j);
         entropy_cond3(na3,t3-1)=-sum(exp3.*p_center3.* p_cond3(na3).*log(abs(exp3.*p_cond3(na3)))); % conditional network flow entropy
         MI_cond3(na3,t3-1)=entropy_node3(na3,t3-1)-entropy_cond3(na3,t3-1);% differential network flow entropy
         MI_sum3(na3)=mean(MI_cond3(na3,:));    
         end
     end  
end
% Stage IIIA network flow entropy
 TNFE_stageIIIA=sum(MI_sum3(:))/total_node_num3;


%%
%Import the files: Stage IIIB-case/adj_network_idx/adj_network_weight
fpi4=fopen('stageIIIB_exp.txt');
hline4 = textscan(fpi4, '%s', 1, 'delimiter', '\n');
field4=textscan(hline4{1}{1},'%s');
clear format4;
format4='%s';
% format4=[format4,' %s'];
for i=2:68
    format4=[format4,' %f'];
end
lines4 =textscan(fpi4, format4,1000000,'delimiter', '\t');
genename4=lines4{1};
pprofile4= [];
for i = 2 :68
    pprofile4 = [pprofile4, lines4{i}];
end
fclose(fpi4);
fid4=fopen('stageIIIB_idx_gene.txt');
stageIIIB_wgcna_network={};
j=0;
while ~feof(fid4)
    tline4=fgetl(fid4);
    j=j+1;
    stageIIIB_wgcna_network{j}=regexp(tline4, '\s+', 'split');
end
fclose(fid4);
total_node_num4=j;
fid4=fopen('stageIIIB_weight_network.txt');
stageIIIB_weight_network={};
j=0;
while ~feof(fid4)
    tline4=fgetl(fid4);
    j=j+1;
    stageIIIB_weight_network{j}=regexp(tline4, '\s+', 'split');
end
fclose(fid4);
pprofile4=abs(pprofile4);
psize4=size(pprofile4);
%Calculate the node probability and local network flow entropy for each network
for na4=1:total_node_num4
     weight_sum4=zeros(length(stageIIIB_weight_network),1);  
     for n4=2:length(stageIIIB_wgcna_network{na4})-1
        nei4=stageIIIB_wgcna_network{na4}{n4};% neighborhood gene in each local network
        ne4=str2num(nei4);
        m4=mean(pprofile4(ne4,1:psize4(2)));% mean of each neighborhood gene
        v4=std(pprofile4(ne4,1:psize4(2)));% standard deviation of each neighborhood gene
        for j=1:psize4(2) 
            p4(n4-1,j)=normpdf(pprofile4(ne4,j),m4,v4);% Gaussian distribution for each neighborhood gene
            p_node4(n4-1,j)=p4(n4-1,j)./sum(p4(n4-1,:));  % node probability of each neighborhood gene
            entropy_node4(na4,n4-1)=-sum(pprofile4(ne4,j).*p_node4(n4-1,j).*log(abs(pprofile4(ne4,j).*p_node4(n4-1,j)))); % local network flow entropy
        end
     end
end
%Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na4=1:total_node_num4
  legt_wegt4(na4)=length(stageIIIB_weight_network{na4});  
end
for na4=1:total_node_num4
     for t4=2:length(stageIIIB_weight_network{na4})-1
         max_legt_wegt4=max(legt_wegt4);
         idx4=stageIIIB_weight_network{na4}{t4};
         id4=str2num(idx4);
         weight_sum4(na4)=weight_sum4(na4)+sum(str2num(char(reshape(stageIIIB_weight_network{na4},legt_wegt4(na4),1))))-na4;
         center4=stageIIIB_wgcna_network{na4}{1};% center gene in each local network
         center4=str2num(center4);
         m_4=mean(pprofile4(center4,1:psize4(2)));% mean of each center gene 
         v_4=std(pprofile4(center4,1:psize4(2)));% standard deviation of each center gene
         for j=1:psize4(2)  
         p44(na4,j)=normpdf(pprofile4(na4,j),m_4,v_4);% Gaussian distribution for each center gene
         p_center4=p44(na4,j)./sum(p44(na4,:)); % node probability of each center gene
         p_cond4(na4,t4-1)=(str2num(stageIIIB_weight_network{na4}{t4}))./weight_sum4(na4);
         exp4=pprofile4(t4-1,j);
         entropy_cond4(na4,t4-1)=-sum(exp4.*p_center4.* p_cond4(na4).*log(abs(exp4.*p_cond4(na4)))); % conditional network flow entropy
         MI_cond4(na4,t4-1)=entropy_node4(na4,t4-1)-entropy_cond4(na4,t4-1);% differential network flow entropy
         MI_sum4(na4)=mean(MI_cond4(na4,:));   
         end
     end   
end
% Stage IIIB network flow entropy
TNFE_stageIIIB=sum(MI_sum4(:))/total_node_num4;


%%
%Import the files: Stage IV-case/adj_network_idx/adj_network_weight
fpi5=fopen('stageIV_exp.txt');
hline5 = textscan(fpi5, '%s', 1, 'delimiter', '\n');
field5=textscan(hline5{1}{1},'%s');
clear format5;
format5='%s';
% format5=[format5,' %s'];
for i=2:56
    format5=[format5,' %f'];
end
lines5=textscan(fpi5, format5,1000000,'delimiter', '\t');
genename5=lines5{1};
pprofile5= [];
for i = 2 :56
    pprofile5 = [pprofile5, lines5{i}];
end
fclose(fpi5);
fid5=fopen('stageIV_idx_gene.txt');
stageIV_wgcna_network={};
j=0;
while ~feof(fid5)
    tline5=fgetl(fid5);
    j=j+1;
    stageIV_wgcna_network{j}=regexp(tline5, '\s+', 'split');
end
fclose(fid5);
total_node_num5=j;
fid5=fopen('stageIV_weight_network.txt');
stageIV_weight_network={};
j=0;
while ~feof(fid5)
    tline5=fgetl(fid5);
    j=j+1;
    stageIV_weight_network{j}=regexp(tline5, '\s+', 'split');
end
fclose(fid5);
pprofile5=abs(pprofile5);
psize5=size(pprofile5);
%Calculate the node probability and local network flow entropy for each network 
for na5=1:total_node_num5
     weight_sum5=zeros(length(stageIV_weight_network),1);
     for n5=2:length(stageIV_wgcna_network{na5})-1  
        nei5=stageIV_wgcna_network{na5}{n5};% neighborhood gene in each local network
        ne5=str2num(nei5);
        m5=mean(pprofile5(ne5,1:psize5(2)));% mean of each neighborhood gene
        v5=std(pprofile5(ne5,1:psize5(2)));% standard deviation of each neighborhood gene
        for j=1:psize5(2) 
            p5(n5-1,j)=normpdf(pprofile5(ne5,j),m5,v5);% Gaussian distribution for each neighborhood gene
            p_node5(n5-1,j)=p5(n5-1,j)./sum(p5(n5-1,:));  % node probability of each neighborhood gene
            entropy_node5(na5,n5-1)=-sum(pprofile5(ne5,j).*p_node5(n5-1,j).*log(abs(pprofile5(ne5,j).*p_node5(n5-1,j)))); % local network flow entropy
        end
     end
end
%Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na5=1:total_node_num5
  legt_wegt5(na5)=length(stageIV_weight_network{na5});  
end
for na5=1:total_node_num5
     for t5=2:length(stageIV_weight_network{na5})-1
         max_legt_wegt5=max(legt_wegt5);
         idx5=stageIV_weight_network{na5}{t5};
         id5=str2num(idx5);
         weight_sum5(na5)=weight_sum5(na5)+sum(str2num(char(reshape(stageIV_weight_network{na5},legt_wegt5(na5),1))))-na5;
         center5=stageIV_wgcna_network{na5}{1};% center gene in each local network
         center5=str2num(center5);
         m_5=mean(pprofile5(center5,1:psize5(2)));% mean of each center gene 
         v_5=std(pprofile5(center5,1:psize5(2)));% standard deviation of each center gene
         for j=1:psize5(2) 
         p55(na5,j)=normpdf(pprofile5(na5,j),m_5,v_5);% Gaussian distribution for each center gene
         p_center5=p55(na5,j)./sum(p55(na5,:)); % node probability of each center gene
         p_cond5(na5,t5-1)=(str2num(stageIV_weight_network{na5}{t5}))./weight_sum5(na5);
         exp5=pprofile5(t5-1,j);
         entropy_cond5(na5,t5-1)=-sum(exp5.*p_center5.* p_cond5(na5).*log(abs(exp5.*p_cond5(na5))));% conditional network flow entropy
         MI_cond5(na5,t5-1)=entropy_node5(na5,t5-1)-entropy_cond5(na5,t5-1);% differential network flow entropy
         MI_sum5(na5)=mean(MI_cond5(na5,:));
         MI_sum5xin=MI_sum5(~isnan(MI_sum5));
         end
     end   
end
% Stage IV network flow entropy
TNFE_stageIV=mean(MI_sum5xin(:));

%%
figure('NumberTitle', 'off', 'Name', 'Disturbance Information Gain');
A=[TNFE_stageI,TNFE_stageII,TNFE_stageIIIA,TNFE_stageIIIB,TNFE_stageIV];
plot((1:5),abs(A),'r','LineWidth',3);
set(gca,'XTick',1:5);
B={'I' 'II' 'IIIA'  'IIIB' 'IV'};
set(gca,'XTickLabel',B);
xlabel('Stage');
ylabel('TNFE score');

