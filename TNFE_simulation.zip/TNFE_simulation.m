clear;
clc;
close all;
%%
e=exp(1);
for i=1:11  %network node
    X(i,1)=rand()*(5-1)+1;
end
delta_t=1;
L=2100;       
N=round(L/delta_t);  
ts=zeros(N,1);
sigma=0.08;  %noise
es=0.000000001;
s=zeros(1,27);
s(1)=-0.5;
s(2)=-0.475;
s(3)=-0.45;
s(4)=-0.4;
s(5)=-0.375;
s(6)=-0.35;
s(7)=-0.325;
s(8)=-0.3;
s(9)=-0.275;
s(10)=-0.25;
s(11)=-0.225;
s(12)=-0.2;
s(13)=-0.175;
s(14)=-0.15;
s(15)=-0.125;
s(16)=-0.1;
s(17)=-0.08;
s(18)=-0.05;
s(19)=-0.02;
s(20)=-0.0001;
s(21)=0.02;
s(22)=0.05;
s(23)=0.08;
s(24)=0.1;
s(25)=0.15;
s(26)=0.18;
s(27)=0.22;
s(28)=0.25;
D= [-1 0 0 1 0 0 0 0 0 0 0;...
    -1 -1 0 0 0 0 0 0 0 0 0;...
    1 0 1 0 0 0 0 0 0 0 0;...
    -1 0 0 -1 0 0 0 0 0 0 0;...
    0 -1 1 0 -1 1 0 0 0 0 0;...
    0 0 0 0 1 -1 1 0 0 0 0 ;...
    0 0 0 0 0 1 -1 0 0 0 0 ;...
    0 0 0 0 1 0 0 -1 0 0 0
    0 0 0 0 1 0 0 0 -1 0 0
    0 0 0 0 1 0 0 0 0 -1 0
    0 0 0 0 1 0 0 0 0 0 -1]; 
sample_num=1;
CC=zeros(11,4,sample_num);   
CC1=zeros(11,4,28);         
%for i=1:20
%    ss(i)=s(28-i);
%end
ss=-0.50:5/2700:-0.45;
%%
%network
fid=fopen('adj_idx_gene.txt');
wgcna_network={};
j=0;
while ~feof(fid)
    tline=fgetl(fid);
    j=j+1;
    wgcna_network{j}=regexp(tline, '\s+', 'split');
end
fclose(fid);
total_node_num=j;
%edge
fid=fopen('adj_weigh_network.txt');
wgcna_weight={};
j=0;
while ~feof(fid)
    tline=fgetl(fid);
    j=j+1;
    wgcna_weight{j}=regexp(tline, '\s+', 'split');
end
fclose(fid);

%%
%mix samples
for ll=1:28
    qq(ll)=0.96^(1/abs(ss(ll)));  
    E=[-2/11*qq(ll) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
    J=D*E*inv(D);
    for i=1:N-1;
        ts(i+1)=ts(i)+delta_t;  
        eJ=e^(J*delta_t);
        for jj=1:11;
            X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma*normrnd(0,1)*delta_t;
        end
    end
    CC1(:,1,ll)=X(:,2000); 
end
stage=28;
pprofile=(reshape(CC1(:,1,:),11,28));
pprofile=abs(pprofile);
psize=size(pprofile); 
tempcase=zeros(11,28); 
patients_num=28;
tempcase(:,1:patients_num)=pprofile(:,1:psize(2)); 

%%
% Calculate the temporal network flow entropy 
for T=1:5
    for t=1:28
        q(t)=0.96^(1/abs(s(t)));
        E=[-2/11*q(t) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
        J=D*E*inv(D);        
        for k=1:sample_num
            for i=1:N-1
                ts(i+1)=ts(i)+delta_t;
                eJ=e^(J*delta_t);
                for jj=1:11
                    X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma*normrnd(0,1)*delta_t;
                end
            end
            CC(:,t,k)=X(:,2000);
        end  
    TC(:,t)=reshape(CC(:,t,:),11,sample_num);
    tempcase(:,patients_num)=TC(:,t); 
    tempcase=abs(tempcase);
    msize=size(tempcase);
    weight_sum=zeros(length(wgcna_weight),1);
    entropy_node=zeros(total_node_num,stage);
% Calculate the node probability and local network flow entropy for each network 
for na=1:total_node_num
     for n=2:length(wgcna_network{na})-1
        nei=wgcna_network{na}{n};% neighborhood gene in each local network
        ne=str2num(nei);
        m1=mean(tempcase(ne,1:msize(2)));% mean of each neighborhood gene
        v1=std(tempcase(ne,1:msize(2))); % standard deviation of each neighborhood gene
     end
      for j=1:msize(2) 
            p(n-1,j)=normpdf(tempcase(ne,j),m1,v1);% Gaussian distribution for each neighborhood gene
            p_node(n-1,j)=p(n-1,j)./sum(p(n-1,:));% node probability of each neighborhood gene
            entropy_node(na,n-1)= -sum(tempcase(n-1,j).*p_node(n-1,j).*log(abs(tempcase(n-1,j).*p_node(n-1,j))))+es; % local network flow entropy
        end
end
%Calculate the conditional network flow entropy and differential network flow entropy for each network 
for na=1:total_node_num
  legt_wegt(na)=length(wgcna_weight{na});  
end
for na=1:total_node_num
     for tt=2:length(wgcna_weight{na})-1
         center=wgcna_network{na}{1};% center gene in each local network
         center=str2num(center);
         m=mean(tempcase(center,1:msize(2)));% mean of each center gene
         v=std(tempcase(center,1:msize(2)));% standard deviation of each center gene
         max_legt_wegt=max(legt_wegt);
         idx=wgcna_weight{na}{tt};
         id=str2num(idx);
         weight_sum(na)=weight_sum(na)+sum(str2num(char(reshape(wgcna_weight{na},legt_wegt(na),1))))-na;
         for j=1:msize(2) 
         p1(na,j)=normpdf(tempcase(na,j),m,v); % Gaussian distribution for each center gene
         p_center(na,j)=p1(na,j)./sum(p1(na,:)); % node probability of each center gene
         p_cond(na,tt-1)=(str2num(wgcna_weight{na}{tt-1}))./weight_sum(na);
         exp=tempcase(tt-1,j);
         entropy_cond(na,tt-1)=-sum(exp.*p_center(na,j).*p_cond(na,tt-1).*log(abs(exp.*p_cond(na,tt-1))))+es;  % conditional network flow entropy
         end
         TNFE_cond(na,t)=sum(abs(entropy_node(na,tt-1)-entropy_cond(na,tt-1)))./(tt-1);% differential network flow entropy
     end 
end
   TNFE(t)=sum(TNFE_cond(:,t))/11; 
    end
end
TNFE1=TNFE/T;
TNFE2=abs(TNFE1/sum(TNFE1));

%%
figure1=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes1 = axes('Parent',figure1);
plot(s(1:28),TNFE2,'r-*','LineWidth',2.5);
line([s(20) s(20)],[0 TNFE2(20)],'linestyle','--','Color','m','LineWidth',1.5);
xlim(axes1,[-0.5 0.25]);
box(axes1,'on');
xlabel('Parameter p');
ylabel('TNFE Score');

figure2=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes2 = axes('Parent',figure2);
b=bar3(TNFE_cond);
for k=1:length(b)
    zdata=b(k).ZData;
    b(k).CData=zdata;
    b(k).FaceColor='interp';
end
set(gca,'XTick',1:29);
B={'-0.5' ' ' ' ' '-0.4 ' ' ' ' ' ' ' '-0.3 ' ' ' ' ' ' ' '-0.2' ' ' ' ' ' ' '-0.1' ' ' ' ' ' ' '0' ' ' ' ' ' ' '0.1' ' ' ' ' ' ' '0.2' ' '};
set(gca,'XTickLabel',B);
xlabel('Parameter');
ylabel('Nodes of network');
zlabel('TNFE score');


