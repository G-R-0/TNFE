clear;
clc;
close all;
%%
% GSE73072_H3N2_subject13
% Import the files: control/case/adj_network_idx/adj_network_weight
% control
fpi=fopen('control.txt');
hline = textscan(fpi, '%s', 1, 'delimiter', '\n');
field=textscan(hline{1}{1},'%s');
clear format;
format='%s';  
for i=2:35
    format=[format,' %f'];
end
lines =textscan(fpi, format,1000000,'delimiter', '\t');
genename=lines{1};
pprofile = [];
for i = 2 :35
    pprofile = [pprofile, lines{i}];
end
fclose(fpi);
% case
fpi=fopen('case.txt');
hline = textscan(fpi, '%s', 1, 'delimiter', '\n');
field=textscan(hline{1}{1},'%s');
clear format;
format='%s';  % format=[format,' %s'];
for i=2:20
    format=[format,' %f'];
end
lines =textscan(fpi, format,1000000,'delimiter', '\t');
genename=lines{1};
mprofile = [];
for i = 2 :20
    mprofile = [mprofile, lines{i}];
end
fclose(fpi);
% idx_gene
fid=fopen('idx_gene.txt');
wgcna_network={};
j=0;
while ~feof(fid)
    tline=fgetl(fid);
    j=j+1;
    wgcna_network{j}=regexp(tline, '\s+', 'split');
end
fclose(fid);
total_node_num=j;
% weight_network
fid=fopen('weight_network.txt');
wgcna_weight={};
j=0;
while ~feof(fid)
    tline=fgetl(fid);
    j=j+1;
    wgcna_weight{j}=regexp(tline, '\s+', 'split');
end
fclose(fid);
% Sample grouping
reference_num=34;
psize=size(pprofile);
tempcontrol=pprofile;
subject_t=[20,20,20,20,20,19,20,20,20,20,20,20,19,20,20,20,20];
stage=subject_t(13);
tempcase=zeros(psize(1),19,35);
patients_num=[35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35];  
for t=1:stage
   tempcase(:,t,1:patients_num(13)-1)=pprofile(:,1:psize(2)); 
   tempcase(:,t,patients_num(13))=mprofile(:,t); 
end
msize=size(tempcase);
tempcase=abs(zscore(tempcase));
%%
% Calculate the node probability and local network flow entropy for each network 
 weight_sum=zeros(length(wgcna_weight),1);
 entropy_node=zeros(total_node_num,stage);
for t=1:stage
for j=1:35
    for i=1:total_node_num
        for n=2:length(wgcna_network{i})-1
        nei=wgcna_network{i}{n};% neighborhood gene in each local network
        ne=str2num(nei);
        m1=sum(tempcase(ne,t,:))/msize(3);% mean of each neighborhood gene
        v1=std(tempcase(ne,t,:));% standard deviation of each neighborhood gene
        p1(n-1,t,j)=normpdf(tempcase(ne,t,j),m1,v1);  % Gaussian distribution for each neighborhood gene
        center=wgcna_network{i}{1};% center gene in each local network
        center=str2num(center);
        m=sum(tempcase(center,t,:))/msize(3);% mean of each center gene 
        v=std(tempcase(center,t,1:msize(3)));% standard deviation of each center gene
        p2(i,t,j)=normpdf(tempcase(i,t,j),m,v);% Gaussian distribution for each center gene
        p_node(n-1,t,j)=p1(n-1,t,j)./sum(p1(n-1,t,:));  % node probability of each neighborhood gene
        entropy_node(i,t)=-sum(tempcase(ne,t,j).*p_node(n-1,t,j).*log(abs(tempcase(ne,t,j).*p_node(n-1,t,j))));% local network flow entropy 
        end
    end       
end
end
% Calculate the conditional network flow entropy and differential network flow entropy for each network 
for i=1:length(wgcna_weight)
  legt_wegt(i)=length(wgcna_weight{i});  
end
for t=1:stage
for j=1:35
for i=1:total_node_num
     for n=2:length(wgcna_weight{i})-1
        nei=wgcna_network{i}{n};
        ne=str2num(nei);
        max_legt_wegt=max(legt_wegt);
        entropy_cond=zeros(total_node_num,max_legt_wegt,stage);
        idx=wgcna_weight{i}{n};
        id=str2num(idx);
        weight_sum(i)=sum(str2num(char(reshape(wgcna_weight{i},legt_wegt(i),1))))-i; 
        p_center=p2(i,t,j)./sum(p2(i,t,:));  % node probability of each center gene
        p_cond(i,n-1)=(str2num(wgcna_weight{i}{n}))./weight_sum(i);
        exp=tempcase(ne,t,j);
        entropy_cond(i,n-1,t)=entropy_cond(i,n-1,t)-exp.*p_center.* p_cond(i,n-1).*log(abs(exp.*p_cond(i,n-1)));% conditional network flow entropy
        TNFE_cond(i,n-1,t)=entropy_node(i,t)-entropy_cond(i,n-1,t);% differential network flow entropy
     end 
         TNFE_sum(i,t)=mean(TNFE_cond(i,:,t));
end  
        TNFE_subject13(t)=sum(TNFE_sum(:,t))/total_node_num;
end
end
% Temporal network flow entropy
b=zscore(TNFE_subject13);
b=b';
c=[b(1),b(2)-b(1),b(3)-b(2),b(4)-b(3),b(5)-b(4),b(6)-b(5),b(7)-b(6),b(8)-b(7),b(9)-b(8),b(10)-b(9),b(11)-b(10),b(12)-b(11),b(13)-b(12),b(14)-b(13),b(15)-b(14)...,
   b(16)-b(15),b(17)-b(16),b(18)-b(17),b(19)-b(18)];

%%
figure('NumberTitle', 'off', 'Name', 'Disturbance Information Gain');
plot([1:1:stage],abs(c),'r','LineWidth',3);
set(gca,'XTick',1:19);
B={ '0h' '5h' '12h' '22h' '29h'  '46h' '53h' '60h' '70h' '77h' '84h' '94h' '101h' '108h' '118h' '125h' '132h' '142h' '166h'};
set(gca,'XTickLabel',B);
xlabel('stage');
ylabel('TNFE score');
title('The Temporal Network Flow Entropy  of flu subject13');